package org.example.code3.service;

import org.example.code3.model.Book;

import java.util.List;

public interface BookService  {

    public void addBook(Book book);

    Book getBookById(String id);

    List<Book>  getReadAllBook();

    public void updateUser(String id, String author);

    public void removeUser(String id);

    Book getTitleByTitle(String title);


}
