package org.example.code3.service;


import org.example.chapter10.Practice01.Item;
import org.example.code3.exception.BookNotFoundException;
import org.example.code3.model.Book;

import java.util.ArrayList;
import java.util.List;

public class BookServiceImpl implements BookService {

    List<org.example.code3.model.Book> bookList = new ArrayList<>();

    @Override
    public void addBook(org.example.code3.model.Book book) {
        bookList.add(book);
    }

    @Override
    public org.example.code3.model.Book getBookById(String id) {

        for (Book book : bookList) {
            if (book.getId().equals(id)) {
                System.out.println(book.toString());

            }
        }

        return null;
    }

    @Override
    public List<org.example.code3.model.Book> getReadAllBook() {
        if (bookList.isEmpty()) {
            System.out.println("책이 없습니다.");
        } else {
            System.out.println("전체 책 조회");
            for (org.example.code3.model.Book book : bookList) {
                System.out.println(book.toString());

            }
        }
        return bookList;
    }

    @Override
    public void updateUser(String id, String author) {
        for (Book book : bookList) {
            if (book.getId().equals(id)) {
                book.setAuthor(author);
            }
        }


    }

    @Override
    public void removeUser(String id) {
        Book remoneBook = null;

        for (Book book: bookList) {
            if (book.getId().equals(id)) {
                remoneBook = book;
                break;
            }
        }
        if (remoneBook != null) {
            bookList.remove((remoneBook));
        }


    }

    @Override
    public org.example.code3.model.Book getTitleByTitle(String title) {

        for (org.example.code3.model.Book book : bookList) {
            if (book.getTitle().contains(title)) {
                System.out.println(book.toString());

            }
        }
        return null;
    }


}
